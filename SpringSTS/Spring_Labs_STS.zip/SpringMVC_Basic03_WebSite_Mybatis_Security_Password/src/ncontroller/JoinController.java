package ncontroller;

import java.security.Principal;
import java.sql.SQLException;

import javax.swing.plaf.synth.SynthSpinnerUI;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.View;

import dao.MemberDao;
import service.MemberService;
import vo.Member;

@Controller
@RequestMapping("/joinus/")
public class JoinController {

	@Autowired
	private MemberService service;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private  SqlSession sqlsession;
	
	@RequestMapping(value="join.htm",method=RequestMethod.GET)
	public String join() {
		//return "join.jsp";
		return "joinus.join"; //폴더명.파일명 <definition name="*.*"
	}
	
	@RequestMapping(value="join.htm",method=RequestMethod.POST)
	public String join(Member member) {
		//회원가입 처리 .... NewMemberDao 
		//System.out.println(member.toString());
		MemberDao memberdao = sqlsession.getMapper(MemberDao.class);
		member.setPwd(this.bCryptPasswordEncoder.encode(member.getPwd()));
		
		try {
				memberdao.insert(member);
		} catch (Exception e) {
				e.printStackTrace();
		} 
		
		return "redirect:/index.htm";  //수정하면 안되면  페이지 다시 요청
	}
	
	//로그인 페이지
	@RequestMapping(value="login.htm" , method=RequestMethod.GET)
	public String login() {
		//return "login.jsp";
		return "joinus.login"; //폴더명.파일명
	}
	
	@RequestMapping(value="confirm.htm",method=RequestMethod.GET)
	public String memberConfirm(){
		return "joinus.memberConfirm";
	}
	
	@RequestMapping(value="confirm.htm",method=RequestMethod.POST)
	public String memberConfirm(
			@RequestParam("password") String rawPassword,
			Principal principal) throws ClassNotFoundException, SQLException{
		String viewpage="";
		
		//회원정보
		Member member = service.getMember(principal.getName());
		
		
		//DB에서 가져온 암호화된 문자열
		String encodedPassword = member.getPwd();
		
		System.out.println("rowPassword : "+rawPassword );
		System.out.println("encodepassword : " + encodedPassword);
		
		boolean result = bCryptPasswordEncoder.matches(rawPassword, encodedPassword);
		
		if(result){
			viewpage="redirect:memberupdate.htm";
		}else{
			viewpage="redirect:confirm.htm";
		}
		
		return viewpage;
	}
	
	
	@RequestMapping(value="memberupdate.htm", method=RequestMethod.GET)
	public String memberUpdate(Model model, Principal principal) throws ClassNotFoundException, SQLException{
		System.out.println("들어왔니??");
		Member member = service.getMember(principal.getName());
		model.addAttribute("member", member);
		return "joinus.memberUpdate";
	}
	
	@RequestMapping(value="memberupdate.htm", method=RequestMethod.POST)
	public String memberUpdate(Model model, Member member, Principal principal) throws ClassNotFoundException, SQLException{
		
		Member updatemember = service.getMember(principal.getName());
		
		updatemember.setName(member.getName());
		updatemember.setcPhone(member.getcPhone());
		updatemember.setEmail(member.getEmail());
		updatemember.setPwd(bCryptPasswordEncoder.encode(member.getPwd()));
		service.updateMember(updatemember);
		return "redirect:/index.htm";
	}
	@RequestMapping(value = "idcheck.htm", method = RequestMethod.POST)
	public @ResponseBody String idCheck(@RequestBody String userid) {
		System.out.println("들어왓느냐?");
		System.out.println(userid);
		System.out.println(userid.substring(7));
		int result = service.idCheck(userid.substring(7));
		System.out.println(result);
		String a = "";
		if (result > 0) {
			System.out.println("아이디 중복");
			a="0";
		} else {
			System.out.println("삽입 실패");
			a="1";
		}
		return a;
	}
	
}





