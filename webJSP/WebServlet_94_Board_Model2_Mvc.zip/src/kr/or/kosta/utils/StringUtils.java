package kr.or.kosta.utils;

public class StringUtils {
	public static String titleSub(String title){
		return title.substring(0, 5);
	}
}
