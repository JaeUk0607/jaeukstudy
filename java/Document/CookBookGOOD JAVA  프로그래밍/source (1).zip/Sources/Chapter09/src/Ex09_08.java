public class Ex09_08 {
	public static void main(String[] args) {
	      String str1 = "Java Programming";
	      String str2 = "Java IT CookBook";
	      
	      System.out.println("�� ���ڿ�1 ==> [" + str1 + "]");
	      System.out.println("�� ���ڿ�2 ==> [" + str2 + "]");
	      
	      System.out.println(str1.compareTo(str2));
	      System.out.println(str1.contains("Java"));
	}
}
