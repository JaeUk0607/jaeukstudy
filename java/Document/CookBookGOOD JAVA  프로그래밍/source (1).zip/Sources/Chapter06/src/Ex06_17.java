public class Ex06_17 {
	public static void main(String[] args) {
		int i;
		i = 0;
		for (;;) {
			System.out.printf("%d  \n", i);
			i++;
		}

	}
}