public class Ex06_05 {
	public static void main(String[] args) {
		int i;

		for (i = 1; i <= 5; i++) {
			System.out.printf("%d \n", i);
		}
	}
}