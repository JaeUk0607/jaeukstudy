public class Ex06_15 {
	public static void main(String[] args) {
		int i, k;

		for (i = 9; i >= 1; i--) {
			for (k = 9; k >= 2; k--) {
				System.out.printf("%3dX%d=%2d", k, i, k * i);
			}
			System.out.printf("\n");
		}
	}
}