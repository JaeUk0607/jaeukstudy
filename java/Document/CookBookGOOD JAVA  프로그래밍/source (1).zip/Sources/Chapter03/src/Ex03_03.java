public class Ex03_03 {
	public static void main(String[] args) {
		System.out.printf("%d / %d = %d", 100, 200, 0.5);
		System.out.printf("\n");
	}
}
