public class Ex03_04 {
	public static void main(String[] args) {
		System.out.printf("%d / %d =  %d  \n", 100, 200, 0.5);
		System.out.printf("%c %c  \n", 'a', 'K');
		System.out.printf("%s %s  \n", "IT CookBook", "JAVA");
	}
}
