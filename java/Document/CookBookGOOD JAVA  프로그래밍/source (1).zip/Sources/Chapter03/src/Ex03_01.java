public class Ex03_01 {
	public static void main(String[] args) {
		System.out.printf("100+100");
		System.out.printf("\n");
		System.out.printf("%d", 100 + 100);
		System.out.printf("\n");
	}
}