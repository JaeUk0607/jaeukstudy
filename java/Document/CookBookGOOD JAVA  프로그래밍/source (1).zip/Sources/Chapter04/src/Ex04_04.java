public class Ex04_04 {
	public static void main(String[] args) {
		int a = 10, b;

		b = a++;
		System.out.printf(" %d \n", b);

		b = ++a;
		System.out.printf(" %d \n", b);
	}
}
