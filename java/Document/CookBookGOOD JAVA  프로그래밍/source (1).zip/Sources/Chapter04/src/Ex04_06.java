public class Ex04_06 {
	public static void main(String[] args) {
		int a = 99;

		System.out.printf(" AND ���� : %s \n", (a >= 100) && (a <= 200));
		System.out.printf(" OR ����  : %s \n", (a >= 100) || (a <= 200));
		System.out.printf(" NOT ���� : %s \n", !(a == 100));
	}
}
