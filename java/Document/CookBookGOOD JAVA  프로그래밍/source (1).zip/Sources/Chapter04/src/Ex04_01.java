public class Ex04_01 {
	public static void main(String[] args) {
		int a, b = 5, c = 3;

		a = b + c;
		System.out.printf(" %d + %d = %d  \n", b, c, a);

		a = b - c;
		System.out.printf(" %d - %d = %d  \n", b, c, a);

		a = b * c;
		System.out.printf(" %d * %d = %d  \n", b, c, a);

		a = b / c;
		System.out.printf(" %d / %d = %d  \n", b, c, a);

		a = b % c;
		System.out.printf(" %d %% %d = %d  \n", b, c, a);
	}
}
