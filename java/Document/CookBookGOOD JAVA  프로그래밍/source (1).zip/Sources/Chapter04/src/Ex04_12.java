public class Ex04_12 {
	public static void main(String[] args) {
		int a = 12345;

		System.out.printf(" %d \n", ~a + 1);
	}
}
