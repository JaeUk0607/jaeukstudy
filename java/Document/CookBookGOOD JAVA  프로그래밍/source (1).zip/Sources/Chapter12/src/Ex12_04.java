/*
class Car {
	private String color;
	int speed;
}

class Sedan extends Car {
	void setSpeed(int speed) {
		this.speed = speed;
	}

	// (����)
	//void setColor(String color) {
	//	 this.color = color;
	//}
	
}

public class Ex12_04 {
	public static void main(String[] args) {

		Sedan sedan1 = new Sedan();

		sedan1.setSpeed(300);
		System.out.println("�¿��� �ӵ� ==> " + sedan1.speed);
	}
}
*/
