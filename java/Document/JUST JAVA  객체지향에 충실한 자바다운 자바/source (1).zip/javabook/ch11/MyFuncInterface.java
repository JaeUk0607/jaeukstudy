package javabook.ch11;

@FunctionalInterface
public interface MyFuncInterface {
	public void go(String s);
}
