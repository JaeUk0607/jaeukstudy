package javabook.ch3;

public class Ch3Ex3 {
	public static void main(String[] args) {
		boolean result = true;
		float num1 = 32.87f;
		double num2 = 3.14E5;
		
		System.out.printf("result : %s \n", result);		
		System.out.printf("num1 : %f \n", num1);
		System.out.printf("num2 : %f \n",num2);
	}
}
