package javabook.ch3;

public class Ch3Ex2 {
	public static void main(String[] args) {
		byte num1 = 'A';
		int result;
		
		short char1 = '}';
		char char2 = 66;
		long num2 = 9876543210L;
		
		System.out.printf("num1 숫자 : %d \n", num1);		
		System.out.printf("num1 문자 : %c \n", num1);
		System.out.printf("char1 숫자 : %d \n",char1);
		System.out.printf("char2 문자 : %c \n",char2);
		System.out.printf("num2 숫자 : %d \n",num2);
		
		result = num1+30;
		System.out.println("num1+30 = "+result);
	}
}