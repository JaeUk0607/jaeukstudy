package javabook.ch3;

public class Ch3Ex1 {
	public static void main(String[] args) {
		int num1 = 12;
		int num2 = 20;
		int result = num1 + num2;
		
		System.out.println(num1+" + "+num2+" = "+result);
		System.out.printf("%d + %d = %d", num1,num2,result);
	}
}