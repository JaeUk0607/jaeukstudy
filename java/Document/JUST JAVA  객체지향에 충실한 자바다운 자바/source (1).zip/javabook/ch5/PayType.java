package javabook.ch5;

// 결재 유형 지정을 위한 enum 타입으로 CASH(현금), CARD(카드) 두가지를 지원함.
public enum PayType {CASH, CARD}