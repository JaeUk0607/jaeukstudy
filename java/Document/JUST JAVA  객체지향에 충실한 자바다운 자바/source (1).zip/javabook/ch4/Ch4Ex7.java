package javabook.ch4;

public class Ch4Ex7 {

	/*
	@Override
	public String toString() {
		return "오버라이딩 예제 입니다.";
	}
	*/
	public static void main(String[] args) {
		Ch4Ex7 exam = new Ch4Ex7();
		Ch4Ex7 exam2 = new Ch4Ex7();
		
		System.out.println(exam.toString());
		System.out.println(exam2.toString());

	}
}
