package javabook.ch4;

public class Ch4Ex4 {
	String msg;
	
	public Ch4Ex4() {
		System.out.println("객체생성 : HelloWorld");
		
	}
	
	public static void main(String[] args) {
		Ch4Ex4 exam = new Ch4Ex4();
	}

}
