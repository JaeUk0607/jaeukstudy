package javabook.ch6;

import java.util.Scanner;

public class Ch6Ex6 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String msg = scan.next();
		System.out.println("입력: "+msg);
		int num = scan.nextInt();
		System.out.println("입력: "+num);
	}
}
