package javabook.exam.ch4;

public class Ch4Exam4_5 {
	public static void main(String[] args) {
		MyCalculator mc = new MyCalculator();
		mc.num1 = 20;
		mc.num2 = 10;
		mc.prtResult();
	}
}
