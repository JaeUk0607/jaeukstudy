package javabook.exam.ch3;

public class Ch3Exam2 {

	public static void main(String[] args) {
		int ch = 'K';
		System.out.printf("%c,%d",ch,ch);
	}
}
