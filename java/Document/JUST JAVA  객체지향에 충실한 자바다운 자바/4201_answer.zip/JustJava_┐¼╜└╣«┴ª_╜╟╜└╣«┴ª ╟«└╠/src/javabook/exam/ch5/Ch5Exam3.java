package javabook.exam.ch5;

public class Ch5Exam3 {
	public static void main(String[] args) {
		MemberManager mm = new MemberManager();		
		mm.prtMem();
	}
}