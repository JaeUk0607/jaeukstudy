package javabook.exam.ch4;

public class Ch4Exam1_3 {

	public static void main(String[] args){
		Car car1 = new Car("현대","제네시스","white",0);
		Car car2 = new Car("기아","쏘렌토","black",0);
		Car car3 = new Car("대우","임팔라","red",0);
		
		// 결과 확인을 위한 출력문을 추가할 수 있음.
		// SportsCar의 경우에도 이곳에 추가해 테스트 하면 됨.
	}

}
