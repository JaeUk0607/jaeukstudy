package javabook.exam.ch2;

public class Ch2Exam3 {

	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("Hello World");
		System.out.println("Hello World");
		
		// 배우지 않았으나 for문 사용시
		for(int i=0;i<3;i++) {
			System.out.println("Hello World");
		}
	}

}
