package javabook.exam.ch5;

public class Ch5Exam1Run {

	public static void main(String[] args) {
		Ch5Exam1 ex = new Ch5Exam1();
		ex.setMemberLevel("YOUNG");
		ex.checkMemberLevel();
	}

}
