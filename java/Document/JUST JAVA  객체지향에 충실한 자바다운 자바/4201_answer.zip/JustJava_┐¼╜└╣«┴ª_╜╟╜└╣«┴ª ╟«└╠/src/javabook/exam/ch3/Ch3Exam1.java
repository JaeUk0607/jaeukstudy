package javabook.exam.ch3;

public class Ch3Exam1 {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 20;
		
		System.out.println(num1 * num2);
	}

}
