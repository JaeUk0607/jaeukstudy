package kr.or.bit.Three;

import java.util.ArrayList;
import java.util.List;

public class Consulting {

	List<Student> studentsList;
	List<Student> consultingList;
	
	public Consulting() {
		studentsList = new ArrayList<>();
		consultingList = new ArrayList<>();
	}
}
