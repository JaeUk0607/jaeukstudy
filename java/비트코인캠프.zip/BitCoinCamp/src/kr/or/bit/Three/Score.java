package kr.or.bit.Three;


public class Score {

	private String lectureName;
	private int score;
	
}
